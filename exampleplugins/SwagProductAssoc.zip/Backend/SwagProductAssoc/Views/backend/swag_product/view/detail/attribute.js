
Ext.define('Shopware.apps.SwagProduct.view.detail.Attribute', {
    extend: 'Shopware.model.Container',
//    padding: 20,

    configure: function() {
        return {
            fieldAlias: 'attribute'
        }
    }
});